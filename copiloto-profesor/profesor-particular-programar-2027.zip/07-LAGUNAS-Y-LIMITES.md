# 07 · DELIMITACIÓN CURRICULAR, LÍMITES Y CONOCIMIENTO COMPLEMENTARIO

## 1. Propósito de este Documento

Este documento establece las **fronteras exactas** entre lo que constituye el currículo canónico oficial del curso **"Programar en 2027"** y aquellos conceptos, herramientas o detalles técnicos que pertenecen al ámbito de la **explicación complementaria**.

Su objetivo es salvaguardar la coherencia del curso y evitar que el profesor particular, el alumnado o el formador conviertan contenidos externos o decisiones pendientes en instrucciones para todo el recorrido.

El pack debe contrastarse con las actividades actuales. La ingeniería de origen conserva diseños y lagunas históricas: consulta su [índice](fuentes/README.md). Si hay una contradicción, identifica ambas fuentes; no presentes la síntesis como evidencia superior al código actual ni decidas por tu cuenta nuevos requisitos.

---

## 2. La Regla de Oro de la Doble Etiqueta

Cada vez que el profesor particular proporcione información técnica al alumnado o al formador de la Red Circular FAB, debe respetar el siguiente marco:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           [SEGÚN EL CURSO]                              │
│  Contenido documentado: señalar fuente y carácter de la actividad.     │
│  Estar documentado no implica formar parte de todos los recorridos.     │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      [EXPLICACIÓN COMPLEMENTARIA]                       │
│  Contexto técnico avanzado, detalles de bajo nivel, buenas prácticas de  │
│  ingeniería y extensiones útiles para el dominio del formador.          │
│  *No forma parte de las seis experiencias publicadas.*                  │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Catálogo de Límites Curriculares y Lagunas Identificadas

| Área Técnica | Alcance Canónico `[SEGÚN EL CURSO]` | Límite / `[EXPLICACIÓN COMPLEMENTARIA]` |
| :--- | :--- | :--- |
| **Preparación del equipo** | [preparacion.html](../preparacion.html) reúne la guía de inicio y paquetes para Windows, Ubuntu y macOS; acompaña la preparación de GitHub, VS Code, Python y las herramientas necesarias. B1-B5 también permiten trabajar con Google Colab. | Las guías de preparación no prueban que el equipo concreto esté listo. Diagnostica con el alumno según su sistema y los mensajes observados; no afirmes haber instalado o verificado programas sin acceso y evidencia. |
| **Control de Versiones (Git)** | Comandos esenciales para flujo local y respaldo en B6-B7: `git init`, `git add`, `git commit -m`, `git status`, `git diff`, `.gitignore` y clonación inicial `git clone`. | No forma parte del temario la gestión avanzada de ramas (`git branch`, `git checkout/switch`), fusión (`git merge`), rebase (`git rebase`) ni resolución interactiva de conflictos de código. |
| **Complejidad Algorítmica (Big-O)** | Explicación cualitativa en lenguaje natural descriptivo: *"acceso instantáneo por clave en diccionarios frente a búsqueda elemento a elemento en listas"*. | No se utiliza ni se evalúa la notación matemática formal Big-O ($O(1), O(N), O(N^2)$). |
| **Mutabilidad y Copias Profundas** | Comprensión de referencias en memoria con listas, copia superficial mediante slicing `b = a[:]` o `.copy()`, e inmutabilidad de tuplas y strings. | No se profundiza en el módulo `copy` (`deepcopy`) para estructuras anidadas complejas ni en el caso de tuplas que contienen listas mutables en su interior. |
| **Generación de Informes en PDF** | Uso canónico de **ReportLab** (`SimpleDocTemplate`, `Paragraph`, `Table`, `Spacer`) para maquetar tablas y resúmenes ejecutivos en B5. | No se cubre maquetación gráfica compleja de imprenta, diseño vectorial milimétrico ni librerías externas no respaldadas en los materiales. |
| **Automatización Web (Scraping)** | Automatización de flujos básicos de navegación, esperas de elementos y extracción de texto visible con **Playwright** en B5. | No se cubren técnicas de evasión de sistemas anti-bot, resolución de captchas ni pipelines distribuidos de scraping masivo. |
| **BeautifulSoup en B5** | Puede aparecer como concepto acotado para parsing de HTML estático si el material actual lo conserva. | No compite con el itinerario práctico principal NumPy -> Pandas -> Playwright -> ReportLab -> Proyecto aplicado 3 y no debe convertirse en dependencia central. |
| **LangGraph en B7** | EXP-05 publicada contiene un grafo ejecutable sin LLM. Las reglas puras se pueden probar sin instalar LangGraph; el grafo queda no verificado si falta. | Se mantiene como ampliación separada. Memoria conversacional, herramientas e intervención humana pertenecen a la ampliación avanzada. |
| **Proyecto final heredado en B7** | Existen guía, registro IA, plan de validación y defensa. La portada de B7 publica además seis experiencias con cuatro proyectos propios. | Queda como antecedente separado y no conduce la ruta publicada. No mezclar sus entregables con las experiencias actuales. |
| **Laboratorio de programación** | Recorrido y laboratorios adicionales documentados en el portal; mapa en 08. | No es B8. Cada experiencia conserva sus prerrequisitos técnicos. |
| **OpenCV en el Lab** | Webcam interactiva con `VideoCapture`, `read`, `imshow`, `waitKey`, `cvtColor`, `GaussianBlur`, `Canny`, `imwrite`, `release` y `destroyAllWindows`. | No incluye reconocimiento facial, reconocimiento de objetos, `CascadeClassifier`, YOLO, MediaPipe ni modelos de IA. |
| **Automatización de archivos del Lab** | Organización de archivos falsos exclusivamente dentro de `lab_archivos_prueba/`. | No recomendar Descargas, Documentos, Escritorio ni carpetas reales externas del alumno. |

---

## 4. Directivas de actuación para el profesor particular

Cuando el formador de Circular FAB consulte sobre algún tema que sobrepase el alcance del curso, el agente debe aplicar el siguiente protocolo:

1. **Aclarar el límite curricular de inmediato:**
   > *"En el temario oficial del curso esto no se exige a los alumnos, ya que el enfoque del bloque está en..."*
2. **Brindar la explicación técnica complementaria para el profesor:**
   > *`[EXPLICACIÓN COMPLEMENTARIA]` "Para tu información como formador, la razón técnica detrás de esto es..."*
3. **Ofrecer una analogía o respuesta simplificada para el aula:**
   > *"Si un alumno curioso te lo pregunta en clase, puedes explicárselo de forma sencilla diciéndole que..."*
4. **Reconducir la atención hacia el objetivo del bloque:**
   > *"Para la práctica de hoy, lo importante es que el grupo domine [Concepto del curso] antes de pasar al siguiente paso."*

## 5. Límites Específicos de ReportLab

Según el curso, ReportLab se trabaja de forma práctica en B5 mediante Platypus. La factura `factura_2027_001.pdf` y el informe PDF del Proyecto aplicado 3 son salidas reales.

El profesor particular no debe presentar como parte de la práctica B5 de factura: OCR, PyPDF, XML, facturación electrónica, normativa fiscal, firma digital, bases de datos ni aplicaciones web de facturación. Las APIs y bases de datos que aparecen después en el Laboratorio de programación no amplían automáticamente B5.

## 6. Límites del Pack Portable

El pack `copiloto-profesor/` es documentación portable. No requiere ni debe proponer para su uso:

- APIs.
- Claves.
- Tokens.
- Backend.
- RAG.
- Bases vectoriales.
- Servicios externos.

Puede cargarse en herramientas compatibles con instrucciones y archivos de conocimiento. La herramienta concreta es decisión del profesor o del centro. Para un proyecto propio, skills, configuraciones o MCP solo se proponen si resuelven una necesidad concreta; no son requisitos del profesor particular ni del curso.

## 7. Diferencias entre versiones y estado tras la evolución

Auditoría documental del 10 de septiembre de 2026, actualizada tras contrastar las rutas publicadas de Programar en 2027:

| Discrepancia encontrada | Criterio operativo del profesor particular | Estado |
| --- | --- | --- |
| B7 conserva guía y plantillas de un proyecto final heredado junto a seis experiencias con cuatro proyectos publicados. | Identificar el material elegido; aplicar tarea acotada → contexto → plan → autorización → diff → pruebas → ACEPTAR/MODIFICAR/RECHAZAR. No mezclar entregables. | **Alcance:** el proyecto final heredado queda fuera de la ruta publicada. |
| La ingeniería y los datos describen LangGraph de forma distinta a EXP-05. | Describir el grafo actual y su Plan B; distinguirlo de la ampliación conversacional. Ollama en EXP-06 se documenta aparte. | **Alcance:** EXP-05 se mantiene como ampliación separada. |
| El JSON del Lab enumera seis prácticas iniciales y no representa el recorrido actual. | Usar el [portal](../lab-python-en-accion/index.html) y el [mapa de 17 experiencias publicadas](08-LAB-PYTHON-EN-ACCION.md); la 20 sigue pendiente de hardware real. | El mapa del pack queda actualizado; el JSON histórico no se cambia en esta microfase. |
| Algunas configs de bloques aún dicen «Pendiente» y las fuentes guardan lagunas ya cubiertas por cuadernos o experiencias. | Consultar los recursos existentes del [mapa de prácticas](04-PRACTICAS-Y-APOYOS.md), no deducir ausencia de contenido de esos metadatos. | Pendiente en su ámbito de mantenimiento. |

El profesor particular no resuelve diferencias cambiando el curso, sus proyectos o sus criterios sin autorización. Sí puede preparar una propuesta acotada conforme al flujo del archivo 00.
